import os
import re
from datetime import datetime
import gradio as gr

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

APP_TITLE = "PNAI | Cloud Database Engineer"

SYSTEM_PROMPT = """You are PNAI, a Cloud Database Engineer assistant specializing in Microsoft SQL Server and Azure SQL Database.
Help with DBaaS design, environment provisioning plans, backup/restore, performance diagnostics, monitoring,
high availability, security, benchmarking, operational reporting, documentation, and continuous improvement.
Be precise and practical. Ask for missing context when needed. Distinguish facts from assumptions.
For SQL, prefer diagnostic/read-only queries first. Explain the purpose and expected output.
Never claim to have connected to or changed a real database unless a configured integration actually did so.
Never request passwords, access tokens, connection strings containing secrets, or private keys.
Any destructive, production, permission-changing, failover, restore, or resource-provisioning action requires
explicit human approval and a verified implementation. Do not run arbitrary SQL or shell commands.
Include risks, validation, rollback/recovery considerations, and a safe next step.
"""

TASKS = {
    "Performance troubleshooting": "Create a diagnostic plan for slow SQL Server/Azure SQL queries. Include safe checks, metrics, likely causes, and validation.",
    "Backup and restore plan": "Design a backup/restore and recovery validation plan. Ask for platform, database size, RPO/RTO, and retention if missing.",
    "Availability / failover": "Recommend a high-availability and disaster-recovery design. Cover RPO/RTO, failover testing, and operational risks.",
    "Security review": "Create a least-privilege security review checklist for SQL Server/Azure SQL. Include identity, network, encryption, auditing, and secrets.",
    "DBaaS provisioning": "Design a repeatable, governed DBaaS provisioning workflow for multiple client applications, including quotas, naming, tagging, and approvals.",
    "Usage and performance report": "Design an availability, capacity, usage, and performance report with metrics, collection frequency, thresholds, and report layout.",
    "Benchmark / load test": "Prepare a safe database benchmarking plan with baseline, workload, concurrency, measurements, and stop conditions.",
    "Runbook / documentation": "Create an operational runbook with prerequisites, procedure, verification, rollback, escalation, and ownership."
}

def redact(text):
    if not text:
        return text
    patterns = [
        (r'(?i)(password|pwd|client_secret|api[_-]?key|access[_-]?token)\s*[:=]\s*[^;\s,]+', r'\1=[REDACTED]'),
        (r'(?i)(Server|Data Source|User ID|UID)\s*=\s*[^;]+', r'\1=[REDACTED]')
    ]
    for pat, repl in patterns:
        text = re.sub(pat, repl, text)
    return text

def fallback_solution(task, platform, environment, context):
    task_lower = (task or "").lower()
    platform = platform or "SQL Server / Azure SQL (not specified)"
    environment = environment or "Not specified"
    common = f"""## Task summary
**Request:** {task or 'No task entered'}
**Platform:** {platform}
**Environment:** {environment}

## Recommended approach
1. Confirm the business impact, affected database/application, time window, and whether this is production.
2. Gather current metrics and relevant error messages. Remove secrets and personal data before sharing logs.
3. Start with read-only diagnostics and compare against a known-good baseline.
4. Review the proposed change in a non-production environment before applying it.
5. Validate results, document evidence, and update the operational runbook.

## Safety and approval
- This starter agent has not connected to or changed a database.
- Review scripts before running them; use a least-privilege account.
- Get explicit approval before production changes, restores, failovers, permission changes, or resource provisioning.
"""
    if any(x in task_lower for x in ["slow", "performance", "query", "blocking", "deadlock"]):
        common += """
## Performance diagnostics
- Check CPU, data I/O, log I/O, memory pressure, waits, active requests, blocking chains, and deadlocks.
- Identify the top queries by total duration, CPU, logical reads, and execution count over the affected time window.
- Inspect actual execution plans and statistics; verify parameter sensitivity and stale statistics before changing indexes.
- Compare Query Store / plan history (where available) before and after the incident.
- Capture a baseline, change one item at a time, and measure latency, throughput, CPU, and reads.

### Safe starter query (SQL Server / Azure SQL-compatible DMV access may vary)
```sql
SELECT TOP (20)
    qs.execution_count,
    CAST(qs.total_elapsed_time / 1000.0 AS decimal(18,2)) AS total_elapsed_ms,
    CAST(qs.total_worker_time / 1000.0 AS decimal(18,2)) AS total_cpu_ms,
    qs.total_logical_reads,
    SUBSTRING(st.text,
      (qs.statement_start_offset/2) + 1,
      ((CASE qs.statement_end_offset WHEN -1 THEN DATALENGTH(st.text)
        ELSE qs.statement_end_offset END - qs.statement_start_offset)/2) + 1) AS statement_text
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
ORDER BY qs.total_worker_time DESC;
```
This is an example diagnostic query, not a complete root-cause analysis. Permissions and DMV availability differ by platform.
"""
    elif any(x in task_lower for x in ["backup", "restore", "recovery"]):
        common += """
## Backup and recovery checklist
- Define recovery point objective (RPO), recovery time objective (RTO), retention, and legal requirements.
- Confirm the platform's automated backup/PITR and long-term retention settings.
- Document restore permissions, target isolation, data validation, and application reconnection steps.
- Test a restore into a non-production target on a schedule; record measured recovery time.
- Never test a restore over production without a reviewed change plan and explicit approval.
"""
    elif any(x in task_lower for x in ["security", "permission", "access", "audit"]):
        common += """
## Security checklist
- Prefer Microsoft Entra ID / managed identity where supported; avoid embedding credentials in code.
- Apply least privilege and separate human, application, and administration identities.
- Review public network access, private endpoints/firewall rules, TLS, encryption, auditing, and threat detection.
- Rotate exposed credentials and store secrets in a managed secret store.
- Validate access changes in a test environment and preserve a rollback path.
"""
    elif any(x in task_lower for x in ["high availability", "failover", "disaster", "availability"]):
        common += """
## High-availability design checklist
- Set explicit RPO/RTO and define regional outage assumptions.
- Select platform-appropriate HA/DR capabilities and confirm service-tier limitations.
- Document failover ownership, client retry behavior, DNS/connection handling, and monitoring alerts.
- Run controlled failover exercises with approval; measure recovery and verify data consistency.
"""
    elif any(x in task_lower for x in ["dbaas", "provision", "provisioning", "environment"]):
        common += """
## DBaaS workflow outline
1. Intake: application owner, data classification, region, service tier, RPO/RTO, capacity, and budget.
2. Policy validation: approved regions, naming, tags, network, identity, encryption, and quota.
3. Approval gate: owner + platform/security approval for production or cost-impacting resources.
4. Provision through reviewed IaC/templates with idempotency and audit logs.
5. Configure monitoring, backup policy, alerts, access, and cost tags.
6. Run smoke tests, publish connection instructions through a secret store, and hand over a runbook.
7. Continuously review utilization, patching, cost, backup success, and access.
"""
    elif any(x in task_lower for x in ["report", "metric", "usage", "monitor"]):
        common += """
## Suggested reporting metrics
- Availability: uptime %, failed connections, incident count, backup success.
- Performance: query duration percentiles, CPU, data/log I/O, waits, blocking, deadlocks.
- Capacity: storage used/free, growth rate, transaction log utilization, DTU/vCore utilization where applicable.
- Operations: deployment/change count, patch status, alert MTTA/MTTR, restore-test age.
- Cost: service tier, reserved capacity where relevant, cost by application/team/environment.
Define metric owner, collection interval, threshold, retention, and escalation for each.
"""
    common += "\n## Context received\n" + (context.strip() if context.strip() else "No additional context supplied.")
    return common

def solve(task, task_type, platform, environment, context, approval_mode):
    task = redact((task or "").strip())
    context = redact((context or "").strip())
    if not task and task_type and task_type != "Custom task":
        task = TASKS.get(task_type, task_type)
    if not task:
        return "Enter a task or choose a task template."
    api_key = os.getenv("OPENAI_API_KEY")
    model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
    if api_key and OpenAI:
        try:
            client = OpenAI(api_key=api_key)
            prompt = f"""Task type: {task_type}
Platform: {platform}
Environment: {environment}
Execution mode: {approval_mode}
User task: {task}
Additional context (redacted): {context}

Provide a solution with: understanding, assumptions/questions, diagnostic steps, scripts only where useful,
expected results, risks, validation, rollback, and approval requirements. Do not execute changes."""
            response = client.responses.create(
                model=model,
                instructions=SYSTEM_PROMPT,
                input=prompt
            )
            return response.output_text
        except Exception as exc:
            return fallback_solution(task, platform, environment, context) + "\n\n---\n**AI API note:** The configured AI request failed. Check OPENAI_API_KEY/model/network settings. No database action was performed."
    return fallback_solution(task, platform, environment, context) + """

## AI mode
This answer was generated using the built-in rule-based fallback. To enable AI-generated, task-specific responses, configure `OPENAI_API_KEY` and optionally `OPENAI_MODEL` in your hosting environment. Do not put API keys in source code or commit them to GitHub.
"""

def template_task(choice):
    return TASKS.get(choice, "") if choice != "Custom task" else ""

with gr.Blocks(title=APP_TITLE, theme=gr.themes.Soft()) as demo:
    gr.Markdown("# ☁️ PNAI — Cloud Database Engineer")
    gr.Markdown("Plan, diagnose, document, and improve SQL Server / Azure SQL operations. **Read-only guidance by default; no database changes are executed by this starter.**")
    with gr.Tab("Tasks"):
        task_type = gr.Dropdown(
            choices=["Custom task"] + list(TASKS.keys()),
            value="Custom task",
            label="Choose a task template"
        )
        task = gr.Textbox(label="Describe the task", placeholder="Example: Diagnose intermittent slow queries on Azure SQL Database...", lines=4)
        with gr.Row():
            platform = gr.Dropdown(
                ["Azure SQL Database", "SQL Server on-premises", "SQL Server on Azure VM", "Azure SQL Managed Instance", "Not sure"],
                value="Azure SQL Database", label="Database platform"
            )
            environment = gr.Dropdown(["Development", "Test / UAT", "Production", "Unknown"], value="Development", label="Environment")
        context = gr.Textbox(label="Additional context (no secrets)", placeholder="Error text, metrics, database size, impact, time window...", lines=4)
        approval_mode = gr.Radio(
            ["Advice only — no changes", "Prepare a change plan for approval"],
            value="Advice only — no changes", label="Execution policy"
        )
        run_btn = gr.Button("Generate solution", variant="primary")
        result = gr.Markdown()
        task_type.change(template_task, inputs=task_type, outputs=task)
        run_btn.click(solve, inputs=[task, task_type, platform, environment, context, approval_mode], outputs=result)
    with gr.Tab("Capabilities"):
        gr.Markdown("""### Supported workflows
- DBaaS provisioning design and environment standards
- Backup, restore, recovery testing and RPO/RTO planning
- Query performance diagnostics and index/statistics review
- Availability, utilization, and performance reporting
- Security and least-privilege review
- High availability / disaster recovery design
- Benchmark planning and runbooks

### Integration status
This starter version provides guidance and example diagnostics. It does **not** connect to SQL Server, Azure, Fabric, or Azure Data Factory. Real integrations require authenticated, least-privilege connectors, monitoring, tests, and explicit approval gates.
""")
    with gr.Tab("Safety & Setup"):
        gr.Markdown("""### Safety rules
1. Never paste passwords, connection strings, API keys, access tokens, or private keys into task context.
2. The agent does not execute SQL or cloud changes.
3. Review scripts and test in non-production first.
4. Require human approval for production changes, restores, failovers, permission changes, and provisioning.
5. Store secrets in hosting environment variables or a managed secret store.

### Enable AI responses
Set `OPENAI_API_KEY` as an environment secret in your hosting platform. Optional: set `OPENAI_MODEL` to a model available to your account. Without the key, the built-in fallback still provides structured guidance.
""")

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=int(os.getenv("PORT", "7860")))
