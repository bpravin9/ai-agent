# PNAI Cloud Database Engineer Agent

A mobile-friendly Gradio starter app for Cloud Database Engineer workflows across Microsoft SQL Server and Azure SQL Database.

## Features
- Dedicated **Tasks** tab with natural-language task input and task templates.
- Performance troubleshooting, backup/restore planning, high availability, security, DBaaS provisioning, reporting, benchmarking, and runbook generation.
- Optional OpenAI Responses API integration.
- Rule-based fallback when no API key is configured.
- Redaction of common secret patterns from task/context text.
- Safe-by-default: no SQL, shell, Azure, Fabric, or database operations are executed.

## Run locally
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://localhost:7860`.

## Configure AI
Set `OPENAI_API_KEY` in the environment or hosting platform's secret settings. Optional `OPENAI_MODEL` defaults to `gpt-4.1-mini`. Never put a real key in `.env.example` or commit it to GitHub.

## Deploy
- **Hugging Face Spaces:** create a Gradio Space and upload `app.py`, `requirements.txt`, and this README. Add `OPENAI_API_KEY` as a Space secret.
- **Docker:** `docker build -t pnai-db-agent .` then `docker run -p 7860:7860 -e OPENAI_API_KEY=... pnai-db-agent`.
- Keep the API key in platform secrets. Do not put secrets in client-side code or public repository files.

## Important scope limitation
This is a task-planning and diagnostic-guidance starter, not yet a live database operations agent. It does not authenticate to or connect to SQL Server, Azure SQL, Azure Data Factory, or Microsoft Fabric, and it does not provision resources, run queries, restore databases, change permissions, or trigger failovers. Those capabilities must be added as narrowly scoped, audited integrations with managed identity/least privilege, test coverage, approval gates, and rollback procedures.

## Recommended integration roadmap
1. Read-only SQL diagnostics via a server-side connector and allowlisted queries.
2. Azure Monitor / Azure SQL metrics collection using managed identity.
3. ADF/Fabric monitoring through supported APIs and read-only scopes.
4. Human approval workflow for typed, allowlisted change requests.
5. Auditing, tests, alerting, secret rotation, and deployment environments.

## Safety
Use synthetic/non-sensitive diagnostic data when testing. Never paste passwords, connection strings, tokens, private keys, or customer confidential data into prompts.
