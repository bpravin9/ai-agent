import importlib.util
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "app.py"
spec = importlib.util.spec_from_file_location("pnai_app", APP)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def test_performance_task_has_diagnostic_guidance():
    result = module.fallback_solution(
        "Diagnose slow query performance", "Azure SQL Database", "Development", ""
    )
    assert "Performance diagnostics" in result
    assert "total_logical_reads" in result

def test_backup_task_has_recovery_guidance():
    result = module.fallback_solution(
        "Create backup and restore plan", "SQL Server", "Test / UAT", ""
    )
    assert "RPO" in result
    assert "non-production" in result

def test_secrets_are_redacted():
    assert "secret123" not in module.redact("client_secret=secret123")
