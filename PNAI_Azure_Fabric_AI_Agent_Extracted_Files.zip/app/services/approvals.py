from datetime import datetime, timezone
from uuid import uuid4
from threading import Lock

_items: list[dict] = []
_lock = Lock()

def request_approval(action: str, reason: str) -> dict:
    item = {
        "id": str(uuid4()),
        "action": action.strip(),
        "reason": reason.strip(),
        "status": "pending",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "note": "Not executed. Approval storage is in-memory and resets on restart.",
    }
    with _lock:
        _items.append(item)
    return item

def list_approvals() -> list[dict]:
    with _lock:
        return list(_items)
