import requests
from app.config import settings

FABRIC_API = "https://api.fabric.microsoft.com/v1"

def _token() -> str | None:
    if not all([settings.fabric_tenant_id, settings.fabric_client_id, settings.fabric_client_secret]):
        return None
    from azure.identity import ClientSecretCredential
    credential = ClientSecretCredential(
        tenant_id=settings.fabric_tenant_id,
        client_id=settings.fabric_client_id,
        client_secret=settings.fabric_client_secret,
    )
    return credential.get_token("https://api.fabric.microsoft.com/.default").token

def list_workspaces() -> dict:
    token = _token()
    if not token:
        return {"configured": False, "message": "Configure Fabric tenant, client ID, and client secret.", "workspaces": []}
    try:
        response = requests.get(
            f"{FABRIC_API}/workspaces",
            headers={"Authorization": f"Bearer {token}"},
            timeout=20,
        )
        if not response.ok:
            return {"configured": True, "error": f"Fabric API returned HTTP {response.status_code}", "workspaces": []}
        data = response.json()
        return {"configured": True, "workspaces": data.get("value", [])}
    except requests.RequestException as exc:
        return {"configured": True, "error": "Fabric request failed.", "detail": type(exc).__name__, "workspaces": []}
