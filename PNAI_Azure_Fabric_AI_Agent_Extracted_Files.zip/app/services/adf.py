from datetime import datetime, timedelta, timezone
from app.config import settings

def list_pipeline_runs(hours: int = 24) -> dict:
    required = [
        settings.azure_subscription_id,
        settings.azure_resource_group,
        settings.adf_factory_name,
    ]
    if not all(required):
        return {
            "configured": False,
            "message": "Set AZURE_SUBSCRIPTION_ID, AZURE_RESOURCE_GROUP, and ADF_FACTORY_NAME.",
            "runs": [],
        }
    try:
        from azure.identity import DefaultAzureCredential
        from azure.mgmt.datafactory import DataFactoryManagementClient
        credential = DefaultAzureCredential()
        client = DataFactoryManagementClient(credential, settings.azure_subscription_id)
        now = datetime.now(timezone.utc)
        result = client.pipeline_runs.query_by_factory(
            settings.azure_resource_group,
            settings.adf_factory_name,
            {
                "last_updated_after": now - timedelta(hours=hours),
                "last_updated_before": now,
            },
        )
        runs = []
        for run in (result.value or []):
            runs.append({
                "run_id": run.run_id,
                "pipeline_name": run.pipeline_name,
                "status": run.status,
                "run_start": run.run_start.isoformat() if run.run_start else None,
                "run_end": run.run_end.isoformat() if run.run_end else None,
                "message": run.message,
            })
        return {"configured": True, "count": len(runs), "runs": runs}
    except Exception as exc:
        # Avoid returning credentials or verbose SDK internals to clients.
        return {"configured": True, "error": "ADF query failed. Check identity, RBAC, network, and factory settings.", "detail": type(exc).__name__, "runs": []}
