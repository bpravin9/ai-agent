from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "PNAI Azure Fabric Agent"
    openai_api_key: str = ""
    openai_model: str = "gpt-4.1-mini"
    azure_subscription_id: str = ""
    azure_resource_group: str = ""
    adf_factory_name: str = ""
    fabric_tenant_id: str = ""
    fabric_client_id: str = ""
    fabric_client_secret: str = ""
    fabric_workspace_id: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

settings = Settings()
