from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from app.config import settings
from app.services.ai import chat
from app.services.adf import list_pipeline_runs
from app.services.fabric import list_workspaces
from app.services.approvals import request_approval, list_approvals

app = FastAPI(title=settings.app_name, version="0.1.0")

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)

class ApprovalRequest(BaseModel):
    action: str = Field(min_length=3, max_length=1000)
    reason: str = Field(min_length=3, max_length=2000)

@app.get("/")
def root():
    return {"name": settings.app_name, "docs": "/docs", "health": "/health"}

@app.get("/health")
def health():
    return {"status": "ok", "app": settings.app_name}

@app.post("/chat")
def chat_route(payload: ChatRequest):
    try:
        return {"response": chat(payload.message)}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"AI request failed ({type(exc).__name__}). Check server configuration.")

@app.get("/azure/adf/pipeline-runs")
def adf_runs(hours: int = Query(default=24, ge=1, le=720)):
    return list_pipeline_runs(hours)

@app.get("/fabric/workspaces")
def fabric_workspaces():
    return list_workspaces()

@app.post("/approvals/request", status_code=202)
def approvals_request(payload: ApprovalRequest):
    return request_approval(payload.action, payload.reason)

@app.get("/approvals")
def approvals_list():
    return {"items": list_approvals()}
