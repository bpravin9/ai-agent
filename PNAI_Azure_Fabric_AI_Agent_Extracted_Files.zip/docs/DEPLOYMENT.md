# Deployment and operations

## Before production
1. Add user authentication (OIDC/OAuth2) and role-based authorization.
2. Put the service behind HTTPS and a gateway/WAF; add rate limiting.
3. Store secrets in Azure Key Vault or the hosting platform's secret manager.
4. Use managed identity for Azure resources when available.
5. Persist approval requests in a database and record immutable audit events.
6. Add monitoring, alerting, log redaction, dependency scanning, and backup policy.
7. Restrict ADF identity to read-only pipeline monitoring permissions.
8. Configure Fabric tenant/service-principal settings and workspace access according to Microsoft guidance.
9. Validate API limits and SDK/API versions in a non-production tenant first.

## Azure Container Apps / App Service
Build the Docker image and deploy using your organization's approved process. Configure environment variables in the host's secret settings. Do not bake secrets into the image.

## GitHub Actions
The workflow runs tests only. For deployment, use workload identity federation/OIDC where supported and environment protection rules; do not save long-lived cloud credentials in repository files.
