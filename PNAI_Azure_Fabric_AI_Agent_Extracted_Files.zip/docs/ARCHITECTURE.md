# Architecture

```text
Mobile/Web client
      |
      | HTTPS (add authentication before public deployment)
      v
FastAPI API  ----> OpenAI API (optional; OPENAI_API_KEY server-side)
   |   |
   |   +----> Approval queue (starter: in-memory; pending only)
   |
   +--------> Azure Data Factory Management SDK (read-only pipeline runs)
   |
   +--------> Microsoft Fabric REST API (read-only workspace listing)

Secrets: environment variables for development; managed secret store in production
CI: GitHub Actions -> install dependencies -> pytest
```

Cloud-changing actions are deliberately excluded. Add an authenticated approval workflow and audit trail before implementing them.
