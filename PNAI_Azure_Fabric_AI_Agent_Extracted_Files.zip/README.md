# PNAI Azure & Microsoft Fabric Agent

A starter project for a natural-language AI assistant with:
- FastAPI chat API powered by the OpenAI API
- Azure Data Factory pipeline monitoring (read-only)
- Microsoft Fabric REST API helper (read-only workspace/pipeline discovery)
- Approval-gated action request pattern for future cloud changes
- Environment-based secrets, automated tests, Dockerfile, and GitHub Actions CI

> This package is a secure starter, not a fully connected production deployment. Azure/Fabric operations require correctly configured credentials and permissions. Cloud-changing operations are intentionally not implemented; requests are recorded as pending approval rather than executed.

## 1. Run locally

Python 3.11+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Add OPENAI_API_KEY to .env if you want AI responses
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open `http://localhost:8000/docs` for the API docs and `http://localhost:8000/health` for health status.

Never commit `.env` or credentials. Use a secret manager in hosted environments.

## 2. API examples

Chat:
```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Explain why an ADF pipeline might fail."}'
```

ADF monitoring:
```bash
curl http://localhost:8000/azure/adf/pipeline-runs?hours=24
```

Fabric workspaces:
```bash
curl http://localhost:8000/fabric/workspaces
```

These cloud endpoints return a clear configuration error until the corresponding credentials and IDs are configured.

## 3. Authentication configuration

### Azure Data Factory
Configure `AZURE_SUBSCRIPTION_ID`, `AZURE_RESOURCE_GROUP`, and `ADF_FACTORY_NAME`. Authentication uses `DefaultAzureCredential`, which supports managed identity in Azure hosting and developer sign-in locally.

Grant only read permissions needed to inspect factory and pipeline runs. Do not grant write permissions for monitoring.

### Microsoft Fabric
Configure `FABRIC_TENANT_ID`, `FABRIC_CLIENT_ID`, `FABRIC_CLIENT_SECRET`, and optionally `FABRIC_WORKSPACE_ID`. Use a dedicated service principal, grant access only to the required workspace, and configure tenant settings to allow the service principal where required. For production, prefer a managed secret store and rotate credentials.

### OpenAI
Set `OPENAI_API_KEY` and optionally `OPENAI_MODEL`. The API returns a safe configuration message when the key is absent.

## 4. Approval and safety
- Cloud changes are not executed by this starter.
- `POST /approvals/request` creates a pending approval record in memory.
- A future implementation should persist approvals, authenticate users, enforce role-based authorization, and revalidate the exact action at approval time.
- Do not expose this API publicly without authentication, TLS, rate limits, and audit logging.
- Never put API keys in source code or client-side mobile apps.

## 5. Tests

```bash
pytest -q
```

## 6. Deploy
Use the Dockerfile or deploy to an approved hosting service. Configure secrets in the host's secret manager. Do not put real secrets in GitHub Actions YAML. The included CI workflow runs tests only.

## 7. Project layout
- `app/main.py` — FastAPI routes
- `app/config.py` — environment configuration
- `app/services/ai.py` — OpenAI chat
- `app/services/adf.py` — read-only ADF pipeline-run monitor
- `app/services/fabric.py` — read-only Fabric REST helper
- `app/services/approvals.py` — pending approval queue
- `tests/` — automated tests
- `.github/workflows/ci.yml` — test workflow
