from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_chat_requires_message():
    response = client.post("/chat", json={"message": ""})
    assert response.status_code == 422

def test_approval_is_pending_and_not_executed():
    response = client.post("/approvals/request", json={
        "action": "Restart pipeline example",
        "reason": "Investigate a failed run first"
    })
    assert response.status_code == 202
    body = response.json()
    assert body["status"] == "pending"
    assert "Not executed" in body["note"]

def test_adf_unconfigured_is_safe(monkeypatch):
    from app.services import adf
    monkeypatch.setattr(adf.settings, "azure_subscription_id", "")
    result = adf.list_pipeline_runs(24)
    assert result["configured"] is False
